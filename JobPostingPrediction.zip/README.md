Execute the Program as follows:

Have Python, and essential libraries installed.
Install Streamlit as given here: https://docs.streamlit.io/library/get-started/installation

Have all files in same folder.
JobPostingPrediction.ipynb has the full classification code.
Job Posting Predictor.py has the webapp
rfc_final has the final Random Forest Classifier model that is already trained over given dataset.

Run the webapp on localhost as follows:
streamlit run Job\ Posting\ Predictor.py
