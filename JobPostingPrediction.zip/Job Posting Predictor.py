import streamlit as st
import joblib
import pandas as pd
# import nltk
# nltk.download("stopwords")
# from nltk.corpus import stopwords
import re

st.write("# Find out if the Job Posting you came across is REAL or FAKE!")

col1, col2, col3 = st.columns(3)

# getting user input
job_id = st.number_input("Job ID:")
title = st.text_input("Job Title", 'Enter Title')
location = st.text_input("Job Location", 'Country, State, City')
department = st.text_input("Department", 'Department')
sal_min = st.number_input("Minimum Salary")
sal_max = st.number_input("Maximum Salary")
company_profile = st.text_area("Company Profile", 'Company Description')
description = st.text_area("Job Description", 'Job Description')
requirements = st.text_area("Requirements", 'Requirements')
benefits = st.text_area("Benefits", 'Benefits')
telecommuting = st.radio("Have Telecommuting?", ('Yes', 'No'))
has_company_logo = st.radio("Does Posting have Company Logo?", ('Yes', 'No'))
has_questions = st.radio("Allows feedback questions?", ('Yes', 'No'))
employment_type = st.selectbox("Employment type", ["Full-Time", "Part-time", "Internship"])
required_experience = st.text_area("Experience", 'Required experience')
required_education = st.selectbox("Education Level", ["Undergraduate", "Postgraduate", "Other"])
industry = st.text_input("Industry", 'Industry')
function = st.text_input("Function", 'Function')

text = title + " "+location+" "+department+" "+company_profile+" "+description+" "+requirements+" "+benefits+" "+employment_type+" "+required_education+" "+industry+" "+function

df_pred = pd.DataFrame([[telecommuting, has_company_logo, has_questions, text]], columns= ['telecommuting', 'has_company_logo', 'has_questions', 'text'])

df_pred['telecommuting'] = df_pred['telecommuting'].apply(lambda x: 1 if x == 'Yes' else 0)

df_pred['has_company_logo'] = df_pred['has_company_logo'].apply(lambda x: 1 if x == 'Yes' else 0)

df_pred['has_questions'] = df_pred['has_questions'].apply(lambda x: 1 if x == 'Yes' else 0)

df_pred['text']= df_pred['text'].str.replace('\n',' ')
df_pred['text']= df_pred['text'].str.replace('\r',' ')
df_pred['text']= df_pred['text'].str.replace('\t',' ')

#This removes unwanted texts
df_pred['text'] = df_pred['text'].apply(lambda x: re.sub(r'[0-9]',' ',x))
df_pred['text'] = df_pred['text'].apply(lambda x: re.sub(r'[/(){}\[\]\|@,;.:-]',' ',x))

#Converting all upper case to lower case
df_pred['text']= df_pred['text'].apply(lambda s:s.lower() if type(s) == str else s)


#Remove un necessary white space
df_pred['text']= df_pred['text'].str.replace('  ',' ')

# stop_words = set(stopwords.words("english"))
# df_pred['text'] = df_pred['text'].apply(lambda x:' '.join([word for word in x.split() if word not in (stop_words)]))
# df_pred['text'][0]



model = joblib.load('rfc_final.pkl')
# prediction = model.predict(df_pred)

if st.button('Find Out Now!'):
    st.write('<p class="big-font">Work In Progress..</p>',unsafe_allow_html=True)
    # if(prediction[0]==0):
    #     st.write('<p class="big-font">REAL JOB! You can go ahead and apply!</p>',unsafe_allow_html=True)
    #
    # else:
    #     st.write('<p class="big-font">FAKE JOB! Beware of fraudulent job postings</p>',unsafe_allow_html=True)
